package com.ust.test;

public class Example {

	public static void main(String[] args) {
		System.out.println("Hello world of JAVA");
		// TODO Auto-generated method stub

	}

}

